/**************************************************************************
 * Copyright (C) 2018 RobotICan, LTD - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 **************************************************************************/
/* Author: Elhay Rauper */

#ifndef RIC_INTERFACE_RIC_OBSERVER_H
#define RIC_INTERFACE_RIC_OBSERVER_H

namespace ric
{
    class RicObserver
    {
    public:
        virtual void on_update(const ric::protocol::package &ric_package) = 0;
    };
}

#endif //RIC_INTERFACE_RIC_OBSERVER_H
