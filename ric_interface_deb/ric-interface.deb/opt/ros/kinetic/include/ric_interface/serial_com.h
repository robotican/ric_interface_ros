/**************************************************************************
 * Copyright (C) 2018 RobotICan, LTD - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 **************************************************************************/
/* Author: Elhay Rauper */



#ifndef RIC_INTERFACE_SERIALCOM_H
#define RIC_INTERFACE_SERIALCOM_H

#include "ric_exception.h"
#include <termios.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/serial.h>
#include <mutex>


typedef unsigned char byte;

#include <string>


class SerialCom
{

private:
    int file_handle_,
            baudrate_;
    void setAttributes();
    std::mutex mutex_;


public:
    ~SerialCom(){ ::close(file_handle_); }
    void connect(std::string port, int baudrate);
    bool send(const byte buff[], size_t size);
    int read(byte buff[], size_t size);
    int read();
    int available();

};



#endif //RIC_INTERFACE_SERIALCOM_H
