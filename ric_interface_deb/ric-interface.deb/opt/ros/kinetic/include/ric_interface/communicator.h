/**************************************************************************
 * Copyright (C) 2018 RobotICan, LTD - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 **************************************************************************/
/* Author: Elhay Rauper */

#ifndef RIC_INTERFACE_COMMUNICATOR_H
#define RIC_INTERFACE_COMMUNICATOR_H

#include <ric_interface/protocol.h>
#include <ric_interface/serial_com.h>
#include <string.h>
#include <iostream>
#include "crc8.h"

namespace ric
{
    typedef uint8_t byte;
    class Communicator
    {

    public:

        enum State
        {
            HEADER_PART_A,
            HEADER_PART_B,
            PACKAGE,
            CHECKSUM
        };

        // goal: connect to serial port
        void connect(std::string port, int baudrate)
        {
            serial_.connect(port, baudrate);
        }

        // goal: read package byte by byte (this function should be read in loop
        //       with no delays.
        // param: referece to bytes array (should be the same reference for all calls)
        // return: if reading is in process, returrn -1, else return the type of the incoming pkg
        int read(byte buff[])
        {
            switch (state_)
            {
                case HEADER_PART_A: //read header
                {
                    if (tryReadHeader())
                    {
                        state_ = HEADER_PART_B;
                      //  puts("got header a");
                    }
                    break;
                }
                case HEADER_PART_B: //read pkg size
                {
                    pkg_size_ = tryReadPkgSize();
                    if (pkg_size_ != -1)
                    {
                        state_ = PACKAGE;
                    //    puts("got header b");

                    }
                    break;
                }
                case PACKAGE:
                {
                    int incoming = serial_.read();
                    if (incoming != -1)
                        buff[pkg_indx_++] = (byte)incoming;

                    if (pkg_indx_ >= pkg_size_) //done reading pkg content
                    {
                      //  puts("got data");
                        state_ = CHECKSUM;

                    }
                    break;
                }
                case CHECKSUM:
                {

                    int incoming = serial_.read();
                    if (incoming != -1)
                    {
                        byte incoming_checksum = (byte)incoming;
                        byte computed_checksum = crc_.get_crc(buff, pkg_size_);
                        //fprintf(stderr, "got chksum: %d, comp chksum: %d\n", incoming_checksum, computed_checksum);

                        reset();

                        if (incoming_checksum == computed_checksum)
                        {

                            //puts("got checksum");
                            protocol::package pkg;
                            fromBytes(buff, sizeof(protocol::package), pkg);
                            return (uint8_t)pkg.type;
                        }

                        //puts("wrong checksum");
                        return -2; //wrong checksum
                    }
                    break;
                }
            }
            return -1;
        }

        // goal: convert bytes to ric package
        static void fromBytes(byte buff[], size_t pkg_size, protocol::package &pkg)
        {
            memcpy(&pkg, buff, pkg_size);
        }

        // goal: convert ric package to bytes
        static void toBytes(const protocol::package &pkg, size_t pkg_size, byte buff[])
        {
            memcpy(buff, &pkg, pkg_size);
        }

        // goal: write package bytes to serial wire. this function build
        // the following package blocks:
        // |header|size|pkg bytes|checksum|
        bool write(const protocol::package &pkg, size_t payload_size)
        {
            // create package buffer
            size_t pkg_size = payload_size + protocol::HEADER_SIZE + protocol::CHKSUM_SIZE;
            byte buff[pkg_size];

            // feed header (header code and package size)
            buff[protocol::HEADER_INDX] = protocol::HEADER_CODE;
            buff[protocol::PAYLOAD_SIZE_INDX] = payload_size;

            // feed pacakge payload bytes
            toBytes(pkg, payload_size, buff + protocol::HEADER_SIZE);

            // compute and feed checksum
            byte checksum = crc_.get_crc(buff + protocol::HEADER_SIZE, payload_size);
            buff[payload_size + protocol::HEADER_SIZE] = checksum;

            bool success = serial_.send(buff, pkg_size);

            if (success)
                return true;
            return false;
        }

        bool isBytesAvailable()
        {
            return (serial_.available() > 0);
        }


    private:
        SerialCom serial_;
        State state_ = HEADER_PART_A;
        int pkg_indx_ = 0;
        int pkg_size_ = 0;
        Crc8 crc_;

        // goal: reset package state (get ready for receiving new package)
        void reset()
        {
            state_ = HEADER_PART_A;
            pkg_indx_ = 0;
            pkg_size_ = 0;
        }

        // goal: try to read valid header start from serial wire
        // return: true if success, false otherwise
        bool tryReadHeader()
        {
            if (serial_.read() == protocol::HEADER_CODE)
                return true;
            return false;
        }

        // goal: try to read package size
        // return: package size if success, -1 otherwise
        int tryReadPkgSize()
        {
            return serial_.read();
        }
    };
}

#endif //RIC_INTERFACE_COMMUNICATOR_H
